ConsoleMD parses markdown using CommonMark-py (implementation of the
CommonMarkdown spec) and then fully renders it to the console in true color.


